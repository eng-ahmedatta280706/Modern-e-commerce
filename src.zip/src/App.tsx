// import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/Home/HomePage';
import ProductPage from './components/ui/product/ProductPage';
import WishlistPage from './pages/Wishlist/WishListPage';
import Layout from './components/layout/Layout';
import { CartProvider } from './contexts/CartContext';
import { WishlistProvider } from './contexts/WishlistContext';
import CheckoutWizard from './pages/Checkout/CheckoutPage';
import UserAccount from './pages/Account/AccountPage';
import LoginPage from './pages/Auth/LoginPage';
import { AuthProvider } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <CartProvider>
          <WishlistProvider>
            <Layout>
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/product/:id" element={<ProductPage />} />
                <Route path="/wishlist" element={<WishlistPage />} />
                <Route path="/checkout" element={<CheckoutWizard />} />
                <Route path="/account" element={<UserAccount />} />
                <Route path="/login" element={<LoginPage />} />
              </Routes>
            </Layout>
          </WishlistProvider>
        </CartProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;