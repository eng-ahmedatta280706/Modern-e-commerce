// import React from 'react';
// import Header from './Header';
// import Footer from './Footer';
// import { useLocation } from 'react-router-dom';
// interface LayoutProps {
//   children: React.ReactNode;
// }
// const Layout: React.FC<LayoutProps> = ({ children }) => {
//   const location = useLocation();
//   const hideFooterPaths = ["/checkout", "/wishlist", "/account" , "/login", "/register"];

//   const shouldShowFooter = !hideFooterPaths.includes(location.pathname);

//   const isAuthPage = ["/login", "/register"].includes(location.pathname);
//   const hideHeaderPaths = ["/checkout", "/wishlist", "/account"];
//   const shouldShowHeader = !hideHeaderPaths.includes(location.pathname) && !isAuthPage;
//   return (
//     <div className="flex flex-col min-h-screen">
//       {shouldShowHeader && <Header />}
//       <main className="flex-grow">{children}</main>
//       {shouldShowFooter && <Footer />}
//     </div>
//   );
// };
// export default Layout;

import React from 'react';
import { useLocation } from 'react-router-dom';
import Header from './Header';   // now imports from Header/index.tsx
import Footer from './Footer';

interface LayoutProps {
  children: React.ReactNode;
}

const HIDE_HEADER_PATHS = ['/checkout', '/login', '/register'];
const HIDE_FOOTER_PATHS = ['/checkout', '/login', '/register' , '/account', '/wishlist'];

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const path = location.pathname;

  const showHeader = !HIDE_HEADER_PATHS.includes(path);
  const showFooter = !HIDE_FOOTER_PATHS.includes(path);

  return (
    <div className="flex flex-col min-h-screen">
      {showHeader && <Header />}
      <main className="flex-grow">{children}</main>
      {showFooter && <Footer />}
    </div>
  );
};

export default Layout;
